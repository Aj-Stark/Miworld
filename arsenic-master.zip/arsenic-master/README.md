![Author Discord Initials: Xandrrrr#7774](https://img.shields.io/badge/Discord-Xandrrrr%237774-important "Author Dsicord Contact Information")

# Arsenic
Arsenic is a customizable moderation, logging, auto-moderation discord bot, with many other features.

## Why Arsenic?

Arsenic let you customize every configuration for your server. You can customize everything in the auto-moderation section or even let you disable/enable commands/whole modules. If you need help you can join our [Support Server](https://discord.gg/JBe55da)!

### Features

 - Auto-moderation (Filtering messages)
 - Much moderation commands
 - Customizable Logging
 - Powerful, customizable Music Implementation
 - Unique information commands (Not all, but some info-cmds are unique)
 - Other Misc and Fun Commands



# Documentation

## Introduction

Here you find everything you need to know, in order to let Arsenic work properly on your Server

2 Little Side Notes:

1. We are using `[] and <>` as placeholders, **don't** use them in the actual commands.
2. All exmaples, which are provided, using the default prefix. If you want to copy those examples, you need to adapt these to your Server and Server-Configuration

## Needed Permissions

The bot needs at least the following permissions, in order to work with minimalistic features:

 - Send Messages
 - Read Messages / View Channel
 - Embed Links
 - Manage Messages
 - Attach Files
 - Add Reactions
 
You can use this Link, if you don't want to set up the role for this Bot: https://discordapp.com/oauth2/authorize?client_id=683635896868012033&scope=bot&permissions=60480
 
In order to use the bot's extensive set of functions and commands, the bot needs the following permissions:

 - Send Messages
 - Read Messages / View Channel
 - Embed Links
 - Manage Messages
 - Attach Files
 - Ban Members
 - Kick Members
 - Manage Roles
 - View Audit Log
 - Add Reactions
 - Connect
 - Speak
 - Move Members
 - Use Voice Activity
 
You can use this Link, if you don't want to set up the role for this Bot: https://discordapp.com/oauth2/authorize?client_id=683635896868012033&scope=bot&permissions=321973446
 
In order to use the bot as a music bot, the bot needs the following permissions:

 - Send Messages
 - Read Messages / View Channel
 - Embed Links
 - Manage Messages
 - Attach Files
 - Connect
 - Speak
 - Use Voice Activity
 
You can use this Link, if you don't want to set up the role for this Bot: https://discordapp.com/oauth2/authorize?client_id=683635896868012033&scope=bot&permissions=36760576

## Configuration

### Change Prefix (Recommend)

We are recommend you to change the prefix from Arsenic, because this will prevent overlapping prefixes with other Bots. It is optional.

You change the prefix from the bot by executing:

```
<CURRENT PREFIX>prefix [New Prefix]
```

##### Example:

```
a!prefix !
```

You forgot the current prefix? No Problem, you get the current prefix by mentioning the Bot.

### Setup a Log-Channel

In order to receive logs and updates from Arsenic, you need to set up a channel as a log-channel. You set up a channel by executing the following command

```
<CURRENT PREFIX>logchannel [Channel-Mention]
```

##### Example:

```
a!logchannel <#701110174039146617>
```

You want to delete the current logchannel? You can do this by replacing the `[Channel-Mention]` with a `reset`

### Activate / Deactivate the log modules

In order to receive logs from specific events, you need to activate or deactivate specific log modules. This is done by sending the following command:

```
<CURRENT PREFIX>togglelogs [One or Multiple Modules, splited by a "Space"]
```

##### Example:

```
a!togglelogs messagedelete messageupdate channelcreate join leave
```

###### Side Note:

You receive the possible modules by executing

```
<CURRENT PREFIX>logmodules
```

This command will give you a big overview about the possible modules and there aliases, as well as a small description about the event itself.

### You want to reset the whole config for your Server?

Slide into our Support Server and mention the Tean, with the Guild ID and optionally the module.
